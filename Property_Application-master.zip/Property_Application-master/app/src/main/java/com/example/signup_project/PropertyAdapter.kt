package com.example.signup_project

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.signup_project.databinding.ItemPropertyBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PropertyAdapter: ListAdapter<PropertyData, PropertyAdapter.PropertyViewHolder>(com.example.signup_project.PropertyDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PropertyViewHolder {
        val binding = ItemPropertyBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PropertyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PropertyViewHolder, position: Int) {
        val property = getItem(position)
        holder.bind(property)
    }

    class PropertyViewHolder(val binding: ItemPropertyBinding) : RecyclerView.ViewHolder(binding.root) {
        private val areaTextView: TextView = binding.areaTextView
        private val addressTextView: TextView = binding.addressTextView
        private val cityTextView: TextView = binding.cityTextView
        private val typeTextView: TextView = binding.typeTextView
        private val roomsTextView: TextView = binding.roomsTextView
        private val kitchensTextView: TextView = binding.kitchensTextView
        private val washroomsTextView: TextView = binding.washroomsTextView
        private val furnishedTextView: TextView = binding.furnishedTextView

        fun bind(property: PropertyData) {
            roomsTextView.text = "Площадь объекта: ${property.rooms}"
            addressTextView.text = "Адрес: ${property.address}"
            cityTextView.text = "Город: ${property.city}"
            typeTextView.text = "Статус объекта: ${property.type}"
            areaTextView.text = "Количество комнат: ${property.area}"
            kitchensTextView.text = "Количество кухонь: ${property.kitchens}"
            washroomsTextView.text = "Количество ванных комнат: ${property.washrooms}"
            furnishedTextView.text = "Наличие мебели: ${property.furnished}"

            val editButton: Button = binding.editButton
            editButton.setOnClickListener {
                val intent = Intent(it.context, EditDataActivity::class.java)
                intent.putExtra("property_id", property.id)
                it.context.startActivity(intent)
            }

            val deleteButton: Button = binding.deleteButton
            deleteButton.setOnClickListener {
                CoroutineScope(Dispatchers.IO).launch {
                    MyAppDatabase.getInstance(it.context).propertyDataDao().deleteProperty(property)
                }

                Toast.makeText(it.context, "Удалено!", Toast.LENGTH_SHORT).show()

            }
        }
    }
}

class PropertyDiffCallback : DiffUtil.ItemCallback<PropertyData>() {
    override fun areItemsTheSame(oldItem: PropertyData, newItem: PropertyData): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: PropertyData, newItem: PropertyData): Boolean {
        return oldItem == newItem
    }
}
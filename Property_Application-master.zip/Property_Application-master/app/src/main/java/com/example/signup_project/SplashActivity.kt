package com.example.signup_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer

class SplashActivity : AppCompatActivity() {

    private val splashDuration: Long = 2000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        object : CountDownTimer(splashDuration, splashDuration) {
            override fun onTick(millisUntilFinished: Long) {
            }

            override fun onFinish() {
                val mainIntent = Intent(this@SplashActivity, SignupActivity::class.java)
                startActivity(mainIntent)
                finish()
            }
        }.start()
    }
}
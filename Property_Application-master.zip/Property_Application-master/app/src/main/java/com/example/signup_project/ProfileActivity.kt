package com.example.signup_project


import UserAdapter
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.example.signup_project.databinding.ActivityProfileBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch



class ProfileActivity : AppCompatActivity() {
    private lateinit var binding: ActivityProfileBinding
    private lateinit var userAdapter: UserAdapter
    private lateinit var database: MyAppDatabase
    private lateinit var currentUserId: String



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        currentUserId = intent.getStringExtra("currentUserId") ?: " "

        database = Room.databaseBuilder(
            applicationContext,
            MyAppDatabase::class.java,
            "myapp_database"
        ).build()

        userAdapter = UserAdapter()
        binding.userRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.userRecyclerView.adapter = userAdapter


        binding.viewProfileButton.setOnClickListener {
            GlobalScope.launch(Dispatchers.IO) {
                val user = database.userDao().getUserById(currentUserId)

                val intent = Intent(this@ProfileActivity, UserProfileActivity::class.java)

                // Pass the user data as extras to the intent
                intent.putExtra("user_name", user?.name)
                intent.putExtra("user_email", user?.email)
                intent.putExtra("user_phone", user?.phone)

                runOnUiThread {
                    startActivity(intent)
                }
            }
        }

        binding.showDataButton.setOnClickListener {
            GlobalScope.launch(Dispatchers.IO) {
                val users = database.userDao().getAllUsers()
                runOnUiThread {
                    userAdapter.submitList(users)
                }
            }
        }
        binding.addpropertyButton.setOnClickListener {
            val intent = Intent(this,InsertPropertyActivity::class.java)
            startActivity(intent)
        }

        binding.veiwpropertyButton.setOnClickListener {
            val intent = Intent(this,ViewPropertyActivity::class.java)
            startActivity(intent)
        }
    }
}
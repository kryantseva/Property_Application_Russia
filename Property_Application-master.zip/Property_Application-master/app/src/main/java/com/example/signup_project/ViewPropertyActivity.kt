package com.example.signup_project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import androidx.core.widget.addTextChangedListener
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.signup_project.databinding.ActivityViewPropertyBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ViewPropertyActivity : AppCompatActivity() {

    private lateinit var binding: ActivityViewPropertyBinding
    private lateinit var propertyAdapter: PropertyAdapter
    private lateinit var database: MyAppDatabase

    private lateinit var searchEditText: EditText
    private lateinit var areaSpinner: Spinner
    private lateinit var citySpinner: Spinner
    private lateinit var typeSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityViewPropertyBinding.inflate(layoutInflater)
        setContentView(binding.root)

        database = MyAppDatabase.getInstance(this)

        val propertyRecyclerView: RecyclerView = binding.propertyRecyclerView
        propertyRecyclerView.layoutManager = LinearLayoutManager(this)
        propertyAdapter = com.example.signup_project.PropertyAdapter()
        propertyRecyclerView.adapter = propertyAdapter

        searchEditText = binding.searchBar
        areaSpinner = binding.areaSpinner
        citySpinner = binding.citySpinner
        typeSpinner = binding.typeSpinner

        initSpinners()

        searchEditText.addTextChangedListener { text ->
            val searchText = text.toString().trim()
            updatePropertyList(searchText)
        }

        areaSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selectedArea = parent?.getItemAtPosition(position).toString()
                updatePropertyList(searchEditText.text.toString().trim(), selectedArea)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        citySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selectedCity = parent?.getItemAtPosition(position).toString()
                updatePropertyList(searchEditText.text.toString().trim(), areaSpinner.selectedItem.toString(), selectedCity)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        typeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selectedType = parent?.getItemAtPosition(position).toString()
                updatePropertyList(searchEditText.text.toString().trim(), areaSpinner.selectedItem.toString(), citySpinner.selectedItem.toString(), selectedType)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        GlobalScope.launch(Dispatchers.IO) {
            val data = database.propertyDataDao().getAllProperties()

            runOnUiThread {
                propertyAdapter.submitList(data)
            }
        }
    }

    private fun initSpinners() {
        val areaData = listOf("Все", "1", "2", "3", "4+")
        val areaAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, areaData)
        areaAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        areaSpinner.adapter = areaAdapter

        val cityData = listOf("Все", "Москва", "Казань", "Челны", "Сочи")
        val cityAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, cityData)
        cityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        citySpinner.adapter = cityAdapter

        val typeData = listOf("Все", "Аренда", "Продажа")
        val typeAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, typeData)
        typeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        typeSpinner.adapter = typeAdapter
    }

    private fun updatePropertyList(
        searchQuery: String = "",
        selectedArea: String = areaSpinner.selectedItem.toString(),
        selectedCity: String = citySpinner.selectedItem.toString(),
        selectedType: String = typeSpinner.selectedItem.toString()
    ) {
        GlobalScope.launch(Dispatchers.IO) {
            val properties = database.propertyDataDao().filterProperties(searchQuery, selectedArea, selectedCity, selectedType)

            runOnUiThread {
                propertyAdapter.submitList(properties)
            }
        }
    }
}
package com.example.signup_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import com.example.signup_project.databinding.ActivityInsertPropertyBinding
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class InsertPropertyActivity : AppCompatActivity()  {

    private lateinit var binding: ActivityInsertPropertyBinding
    private lateinit var db:MyAppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInsertPropertyBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val areaOptions = arrayOf("Количество комнат", "1", "2", "3", "4 и более")
        val typeOptions = arrayOf("Статус жилья", "Аренда", "Продажа")
        val furnishedOptions = arrayOf("Наличие мебели", "Есть", "Нет")

        val areaAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, areaOptions)
        val typeAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, typeOptions)
        val furnishedAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, furnishedOptions)

        areaAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        typeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        furnishedAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        binding.areaSpinner.adapter = areaAdapter
        binding.typeSpinner.adapter = typeAdapter
        binding.furnishedSpinner.adapter = furnishedAdapter

        binding.saveButton.setOnClickListener {
            val area = binding.areaSpinner.selectedItem.toString()
            val address = binding.addressEditText.text.toString()
            val city = binding.cityEditText.text.toString()
            val type = binding.typeSpinner.selectedItem.toString()
            val rooms = binding.roomsEditText.text.toString()
            val kitchens = binding.kitchensEditText.text.toString()
            val washrooms = binding.washroomsEditText.text.toString()
            val furnished = binding.furnishedSpinner.selectedItem.toString()

            val propertyData = com.example.signup_project.PropertyData(
                area = area,
                address = address,
                city = city,
                type = type,
                rooms = rooms,
                kitchens = kitchens,
                washrooms = washrooms,
                furnished = furnished
            )
            saveUserDataToDatabase(propertyData)
            Toast.makeText(it.context,"Сохранено!", Toast.LENGTH_LONG).show()
            val intent = Intent(this,ProfileActivity::class.java)
            startActivity(intent)
        }
    }

    private fun saveUserDataToDatabase(propertyData: PropertyData) {
        db = MyAppDatabase.getInstance(this)
        GlobalScope.launch {
            db.propertyDataDao().insertProperty(propertyData)
        }
    }

}
package com.example.signup_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.lifecycle.lifecycleScope
import com.example.signup_project.databinding.ActivityEditDataBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class EditDataActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditDataBinding
    private lateinit var database: MyAppDatabase
    private var propertyId: Long = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditDataBinding.inflate(layoutInflater)
        setContentView(binding.root)

        database = MyAppDatabase.getInstance(this)

        propertyId = intent.getLongExtra("property_id", -1)

        GlobalScope.launch(Dispatchers.IO) {
            val property = database.propertyDataDao().getPropertyById(propertyId)

            if (property != null) {
                runOnUiThread {
                    initSpinners()

                    populateUI(property)

                    binding.saveButton.setOnClickListener {
                        saveEditedData(property)

                        val intent = Intent(this@EditDataActivity, ProfileActivity::class.java)
                        startActivity(intent)
                        finish()
                    }
                }
            } else {
            }
        }
    }

    private fun initSpinners() {
        val areaData = listOf("1", "2", "3", "4+")
        var areaAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, areaData)
        areaAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.areaSpinner.adapter = areaAdapter


        val typeData = listOf("Аренда", "Продажа")
        var typeAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, typeData)
        typeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.typeSpinner.adapter = typeAdapter

        val furnishedData = listOf("Есть", "Нет")
        var furnishedAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, furnishedData)
        furnishedAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.furnishedSpinner.adapter = furnishedAdapter

        binding.areaSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }

        binding.typeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }

        binding.furnishedSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }
    }

    private fun populateUI(property: PropertyData) {
        binding.areaSpinner.setSelection(getAreaIndex(property.area))
        binding.addressEditText.setText(property.address)
        binding.cityEditText.setText(property.city)
        binding.typeSpinner.setSelection(getTypeIndex(property.type))
        binding.roomsEditText.setText(property.rooms.toString())
        binding.kitchensEditText.setText(property.kitchens.toString())
        binding.washroomsEditText.setText(property.washrooms.toString())
        binding.furnishedSpinner.setSelection(getFurnishedIndex(property.furnished))
    }

    private fun saveEditedData(property: PropertyData) {
        val updatedArea = binding.areaSpinner.selectedItem.toString()
        val updatedAddress = binding.addressEditText.text.toString()
        val updatedCity = binding.cityEditText.text.toString()
        val updatedType = binding.typeSpinner.selectedItem.toString()
        val updatedRooms = binding.roomsEditText.text.toString()
        val updatedKitchens = binding.kitchensEditText.text.toString()
        val updatedWashrooms = binding.washroomsEditText.text.toString()
        val updatedFurnished = binding.furnishedSpinner.selectedItem.toString()

        property.area = updatedArea
        property.address = updatedAddress
        property.city = updatedCity
        property.type = updatedType
        property.rooms = updatedRooms
        property.kitchens = updatedKitchens
        property.washrooms = updatedWashrooms
        property.furnished = updatedFurnished

        GlobalScope.launch(Dispatchers.IO) {
            database.propertyDataDao().updateProperty(property)
            finish()
        }
    }

    private fun getAreaIndex(area: String): Int {
        val areaData = binding.areaSpinner.adapter as ArrayAdapter<String>
        return areaData.getPosition(area)
    }

    private fun getTypeIndex(type: String): Int {
        val typeData = binding.typeSpinner.adapter as ArrayAdapter<String>
        return typeData.getPosition(type)
    }

    private fun getFurnishedIndex(furnished: String): Int {
        val furnishedData = binding.furnishedSpinner.adapter as ArrayAdapter<String>
        return furnishedData.getPosition(furnished)
    }
}